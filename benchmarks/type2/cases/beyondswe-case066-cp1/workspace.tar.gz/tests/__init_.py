"""All the tests"""
