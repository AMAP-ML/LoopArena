"""The Prompts tests"""
