Implement happy eyeballs
